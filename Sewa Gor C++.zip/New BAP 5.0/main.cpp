#include <iostream>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include <iomanip>

using namespace std;

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

int main()
{
    /*========================================== INPUT DATA INTERNAL ====================================== */
    int o=0, i=0, n=0, sewa[10]={0,0,0,0};
    string nama[100];
    char yt;
    string team[100];
    long futhar= 150000;
    long futjam= 50000;
    long badhar= 250000;
    long badjam= 70000;
    string harjam[100];
    long bayar[10]={0,0,0,0};
    string choice;
    string hari_sewa[100];
    string liat_jadwal;
    /* ======================================= MENU UTAMA ========================================== */
    menu_pembuka:
    system("cls");
    char tkb=201, gps=205, db=203, tak=200, tbk= 187, tka=188, gba=186, da=202, tab=204, tba=185;
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout<<"\t\t\t"<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
    cout<<"\t\t\t"<<gba<<"                      Selamat Datang Di Gor                      "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<"                            STAY COOL                            "<<gba<<endl;
    cout<<"\t\t\t"<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<db<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
    cout<<"\t\t\t"<<gba<<"                                "<<gba<<"                                "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<"                                "<<gba<<"                                "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<"                                "<<gba<<"  Pilihan  Menu :               "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<"                                "<<gba<<"1. Mulai Sewa Gor               "<<gba<<endl;
    //perbatasan
    cout<<"\t\t\t"<<gba<<" "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<"  "<<tkb<<gps<<gps<<gps<<gps<<gps<<tbk<<"    "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<"   "<<gba<<"2. Lihat Penyewaan Gor          "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<" "<<gba<<"         "<<gba<<"     "<<gba<<"    "<<gba<<"         "<<gba<<"3. Tentang Gor                  "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<" "<<gba<<"    "<<gps<<gps<<tbk<<"  "<<gba<<"     "<<gba<<"    "<<gba<<"         "<<gba<<"                                "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<" "<<gba<<"      "<<gba<<"  "<<gba<<"     "<<gba<<"    "<<gba<<"         "<<gba<<"     *********************      "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<" "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<"  "<<tak<<gps<<gps<<gps<<gps<<gps<<tka<<"    "<<gba<<"         "<<gba<<"                                "<<gba<<endl;
    //perbatasan
    cout<<"\t\t\t"<<gba<<"                                "<<gba<<" Pilihan Anda Nomor = _         "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<"                                "<<gba<<"                                "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<"                                "<<gba<<"                                "<<gba<<endl;
    cout<<"\t\t\t"<<gba<<"                                "<<gba<<"                                "<<gba<<endl;
    cout<<"\t\t\t"<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<da<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;

    gotoxy(80,18);
    cin>>n;

    switch(n){

    default:
        cout<<"Invalid Input The Characters"<<endl;
        getch();
        goto menu_pembuka;
        break;

    case 1:
        pilihgor: /*========================================== Login - PILIHAN 1 =================================================*/
            o = o+1;
            system("cls");
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<"\t\t\t\t\t"<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"           DAFTAR SEBAGAI         "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<" Nama = _________________________ "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<" TEAM = _________________________ "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
            gotoxy(49,9);
            cin>>nama[o];
            gotoxy(49,11);
            cin>>team[o];

            pilihan_hari: /*============================================= INPUT 1 - PILIHAN 1 ======================================================= */
            system("cls");
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<"\t\t\t\t\t"<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;;
            cout<<"\t\t\t\t\t"<<gba<<"           DAFTAR HARI                            "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"                                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<" Hari = 1. Senin                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        2. Selasa                                 "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        3. Rabu                                   "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        4. Kamis                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        5. Jum'at                                 "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        6. Sabtu                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        7. Minggu                                 "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"                                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<" Silahkan Input Penyewaan nya Hari ______         "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
            gotoxy(76,17);
            cin>>hari_sewa[o];
            if(hari_sewa[o]=="senin"){
                hari_sewa[o]== "senin";
            }
            else if(hari_sewa[o]=="selasa"){
                hari_sewa[o]=="selasa";
            }
            else if(hari_sewa[o]=="rabu"){
                hari_sewa[o]=="rabu";
            }
            else if(hari_sewa[o]=="kamis"){
                hari_sewa[o]=="kamis";
            }
            else if(hari_sewa[o]=="jumat"){
                hari_sewa[o]=="jumat";
            }
            else if(hari_sewa[o]=="sabtu"){
                hari_sewa[o]=="sabtu";
            }
            else if(hari_sewa[o]=="minggu"){
                hari_sewa[o]=="minggu";
            }
            else{
                cout<<"Invalid Input The Characters"<<endl;
                goto pilihan_hari;
            }
            pilihan_gor: /*======================================== INPUT 2 - PILIHAN 1 ======================================================== */
            system("cls");
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<"\t\t========================================================================================"<<endl;
            cout<<"\t\t"<<gba<<"                                     STAY COOL GOR                                    "<<gba<<endl;
            cout<<"\t\t"<<gba<<"                        Jln. Yuk Bosen Nih, No.7, Kec. Suka Mendeng                   "<<gba<<endl;
            cout<<"\t\t"<<gba<<"                    Telp. 010101110101 || Email : staycoolaja@Gor.mail                "<<gba<<endl;
            cout<<"\t\t========================================================================================"<<endl;
            cout<<"\t\t"<<gba<<" Kami Menyediakan beberapa gor terbaik kami, diantaranya :                            "<<gba<<endl;
            cout<<"\t\t"<<gba<<" GOR 1. Futsal                                                                        "<<gba<<endl;
            cout<<"\t\t"<<gba<<"     2. Bulu Tangkis                                                                  "<<gba<<endl;
            cout<<"\t\t========================================================================================"<<endl;
            cout<<"\t\t"<<gba<<" Pilihan Anda =                                                                       "<<gba<<endl;
            gotoxy(33,14);
            cin>>n;
            cout<<"\t\t========================================================================================"<<endl;
            if(n==0 || n>2){
                cout<<"Tidak ada ";
                getch(); goto pilihan_gor;
            }
            else if(n==1){
                futsal:
                system("cls");
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<"                                     STAY COOL GOR                                    "<<gba<<endl;
                cout<<"\t\t"<<gba<<"                        Jln. Yuk Bosen Nih, No.7, Kec. Suka Mendeng                   "<<gba<<endl;
                cout<<"\t\t"<<gba<<"                    Telp. 010101110101 || Email : staycoolaja@Gor.mail                "<<gba<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<" Rincian harga sewa GOR futsal :                                                      "<<gba<<endl;
                cout<<"\t\t"<<gba<<" 1. Harga sewa gor futsal per jam Rp."<<futjam<<"                                            "<<gba<<endl;
                cout<<"\t\t"<<gba<<" 2. Harga sewa gor futsal per hari Rp."<<futhar<<"                                          "<<gba<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<" Silahkan pilih kategori sewa nya [jam/hari] = ____                                   "<<gba<<endl;
                gotoxy(64,14);
                cin>>harjam[o];
                if(harjam[o]== "jam"){
                    cout<<"\t\t"<<gba<<" Berapa Jam nyewa nya = ";
                    cin>>sewa[o];
                    bayar[o]= sewa[o]*futjam;
                }
                else if(harjam[o]== "hari"){
                    cout<<"\t\t"<<gba<<" Berapa Hari nyewa nya = ";
                    cin>>sewa[o];
                    bayar[o]= sewa[o]*futhar;
                }
                else{
                    cout<<"Invalid input the characters"<<endl;
                    goto futsal;
                }

            }
            else if(n==2){
                badminton:
                system("cls");
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<"                                     STAY COOL GOR                                    "<<gba<<endl;
                cout<<"\t\t"<<gba<<"                        Jln. Yuk Bosen Nih, No.7, Kec. Suka Mendeng                   "<<gba<<endl;
                cout<<"\t\t"<<gba<<"                    Telp. 010101110101 || Email : staycoolaja@Gor.mail                "<<gba<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<" Rincian harga sewa GOR Badminton :                                                   "<<gba<<endl;
                cout<<"\t\t"<<gba<<" 1. Harga sewa gor Badminton per jam Rp."<<badjam<<"                                         "<<gba<<endl;
                cout<<"\t\t"<<gba<<" 2. Harga sewa gor Badminton per hari Rp."<<badhar<<"                                        "<<gba<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<" Silahkan pilih kategori sewa nya [jam/hari] = ____                                   "<<gba<<endl;
                gotoxy(64,14);
                cin>>harjam[o];
                if(harjam[o]=="jam"){
                    cout<<"\t\t"<<gba<<" Berapa Jam nyewa nya = ";
                    cin>>sewa[o];
                    bayar[o]= sewa[o]*badjam;
                }
                else if(harjam[o]=="hari"){
                    cout<<"\t\t"<<gba<<" Berapa Hari nyewa nya = ";
                    cin>>sewa[o];
                    bayar[o]= sewa[o]*badhar;
                }
            }
            output_1: /*========================================= Bentuk OUTPUT ================================================== */
            system("cls");
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<"                                     STAY COOL GOR                                    "<<gba<<endl;
                cout<<"\t\t"<<gba<<"                        Jln. Yuk Bosen Nih, No.7, Kec. Suka Mendeng                   "<<gba<<endl;
                cout<<"\t\t"<<gba<<"                    Telp. 010101110101 || Email : staycoolaja@Gor.mail                "<<gba<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<" Nama Penyewa = "<<nama[o]<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                cout<<"\t\t"<<gba<<" Tipe Gor             "<<"Bayar"<<endl;
                cout<<"\t\t"<<gba<<" "<<n<<"                     "<<bayar[o]<<endl;
                cout<<"\t\t========================================================================================"<<endl;
                out_cho:
                cout<<"\t\t"<<gba<<"Input 0 untuk kembali ke menu utama = ";cin>>choice;
                if(choice=="o"||choice=="O"||choice=="0"){
                    goto menu_pembuka;
                }
                else{
                    cout<<"Invalid Input The Characters"<<endl;
                    goto out_cho;
                }


            break;

    case 2: /*=============================================================== PILIHAN 2 ========================================================*/
            coba:
            system("cls");
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<"\t\t\t\t\t"<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;;
            cout<<"\t\t\t\t\t"<<gba<<"           DAFTAR HARI                            "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"                                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<" Hari = 1. Senin                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        2. Selasa                                 "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        3. Rabu                                   "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        4. Kamis                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        5. Jum'at                                 "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        6. Sabtu                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"        7. Minggu                                 "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<"                                                  "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<gba<<" Silahkan Input Penyewaan nya Hari ______         "<<gba<<endl;
            cout<<"\t\t\t\t\t"<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
            gotoxy(76,17);
            cin>>liat_jadwal;
            if(liat_jadwal=="senin"||liat_jadwal=="1"){
                if(hari_sewa[o]== "senin"){
                    cout<<"\t\t\t\t\t\t\t"<<"DAFTAR PENYEWA"<<endl;
                        cout<<"   "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"   "<<gba<<" No."<<"   "<<"Nama"<<"                     "<<"Nama TEAM"<<"                 "<<"Gor"<<"            "<<"Lama Sewa"<<"     "<<"Sewa Per"<<"     "<<"Bayar"<<"      "<<gba<<endl;
                        cout<<"   "<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
                    for(i=1;i<=o;i++){
                        cout<<"   "<<gba<<" "<<setiosflags(ios::left)<<setw(6)<<i;
                        cout<<setiosflags(ios::left)<<setw(25)<<nama[i];
                        cout<<setiosflags(ios::left)<<setw(26)<<team[i];
                        cout<<setiosflags(ios::left)<<setw(15)<<hari_sewa[i];
                        cout<<setiosflags(ios::left)<<setw(14)<<sewa[i];
                        cout<<setiosflags(ios::left)<<setw(13)<<harjam[i];
                        cout<<setiosflags(ios::left)<<setw(11)<<bayar[i]<<gba<<endl;
                    }
                        cout<<"   "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                    getch(); goto menu_pembuka;
                }
            else{
                    goto coba;
                }
            }
            else if(liat_jadwal=="selasa"||liat_jadwal=="2"){
                hari_sewa[o]== "selasa";
                    cout<<"\t\t\t\t\t\t\t"<<"DAFTAR PENYEWA"<<endl;
                        cout<<"   "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"   "<<gba<<" No."<<"   "<<"Nama"<<"                     "<<"Nama TEAM"<<"                 "<<"Gor"<<"            "<<"Lama Sewa"<<"     "<<"Sewa Per"<<"     "<<"Bayar"<<"      "<<gba<<endl;
                        cout<<"   "<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
                    for(i=1;i<=o;i++){
                        cout<<"   "<<gba<<" "<<setiosflags(ios::left)<<setw(6)<<i;
                        cout<<setiosflags(ios::left)<<setw(25)<<nama[i];
                        cout<<setiosflags(ios::left)<<setw(26)<<team[i];
                        cout<<setiosflags(ios::left)<<setw(15)<<hari_sewa[i];
                        cout<<setiosflags(ios::left)<<setw(14)<<sewa[i];
                        cout<<setiosflags(ios::left)<<setw(13)<<harjam[i];
                        cout<<setiosflags(ios::left)<<setw(11)<<bayar[i]<<gba<<endl;
                    }
                        cout<<"   "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                    getch(); goto menu_pembuka;
                }
            else if(liat_jadwal=="rabu"||liat_jadwal=="3"){
                hari_sewa[o]== "rabu";
                    cout<<"\t\t\t\t\t\t\t"<<"DAFTAR PENYEWA"<<endl;
                        cout<<"   "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"   "<<gba<<" No."<<"   "<<"Nama"<<"                     "<<"Nama TEAM"<<"                 "<<"Gor"<<"            "<<"Lama Sewa"<<"     "<<"Sewa Per"<<"     "<<"Bayar"<<"      "<<gba<<endl;
                        cout<<"   "<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
                    for(i=1;i<=o;i++){
                        cout<<"   "<<gba<<" "<<setiosflags(ios::left)<<setw(6)<<i;
                        cout<<setiosflags(ios::left)<<setw(25)<<nama[i];
                        cout<<setiosflags(ios::left)<<setw(26)<<team[i];
                        cout<<setiosflags(ios::left)<<setw(15)<<hari_sewa[i];
                        cout<<setiosflags(ios::left)<<setw(14)<<sewa[i];
                        cout<<setiosflags(ios::left)<<setw(13)<<harjam[i];
                        cout<<setiosflags(ios::left)<<setw(11)<<bayar[i]<<gba<<endl;
                    }
                        cout<<"   "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                    getch(); goto menu_pembuka;
                }
        else if(liat_jadwal=="kamis"||liat_jadwal=="4"){
                hari_sewa[o]== "kamis";
                    cout<<"\t\t\t\t\t\t\t"<<"DAFTAR PENYEWA"<<endl;
                        cout<<"   "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"   "<<gba<<" No."<<"   "<<"Nama"<<"                     "<<"Nama TEAM"<<"                 "<<"Gor"<<"            "<<"Lama Sewa"<<"     "<<"Sewa Per"<<"     "<<"Bayar"<<"      "<<gba<<endl;
                        cout<<"   "<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
                    for(i=1;i<=o;i++){
                        cout<<"   "<<gba<<" "<<setiosflags(ios::left)<<setw(6)<<i;
                        cout<<setiosflags(ios::left)<<setw(25)<<nama[i];
                        cout<<setiosflags(ios::left)<<setw(26)<<team[i];
                        cout<<setiosflags(ios::left)<<setw(15)<<hari_sewa[i];
                        cout<<setiosflags(ios::left)<<setw(14)<<sewa[i];
                        cout<<setiosflags(ios::left)<<setw(13)<<harjam[i];
                        cout<<setiosflags(ios::left)<<setw(11)<<bayar[i]<<gba<<endl;
                    }
                        cout<<"   "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                    getch(); goto menu_pembuka;
            }
        else if(liat_jadwal=="jumat"||liat_jadwal=="5"){
                hari_sewa[o]== "jumat";
                    cout<<"\t\t\t\t\t\t\t"<<"DAFTAR PENYEWA"<<endl;
                        cout<<"   "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"   "<<gba<<" No."<<"   "<<"Nama"<<"                     "<<"Nama TEAM"<<"                 "<<"Gor"<<"            "<<"Lama Sewa"<<"     "<<"Sewa Per"<<"     "<<"Bayar"<<"      "<<gba<<endl;
                        cout<<"   "<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
                    for(i=1;i<=o;i++){
                        cout<<"   "<<gba<<" "<<setiosflags(ios::left)<<setw(6)<<i;
                        cout<<setiosflags(ios::left)<<setw(25)<<nama[i];
                        cout<<setiosflags(ios::left)<<setw(26)<<team[i];
                        cout<<setiosflags(ios::left)<<setw(15)<<hari_sewa[i];
                        cout<<setiosflags(ios::left)<<setw(14)<<sewa[i];
                        cout<<setiosflags(ios::left)<<setw(13)<<harjam[i];
                        cout<<setiosflags(ios::left)<<setw(11)<<bayar[i]<<gba<<endl;
                    }
                        cout<<"   "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                    getch(); goto menu_pembuka;
            }
            else if(liat_jadwal=="sabtu"||liat_jadwal=="6"){
                hari_sewa[o]== "sabtu";
                    cout<<"\t\t\t\t\t\t\t"<<"DAFTAR PENYEWA"<<endl;
                        cout<<"   "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"   "<<gba<<" No."<<"   "<<"Nama"<<"                     "<<"Nama TEAM"<<"                 "<<"Gor"<<"            "<<"Lama Sewa"<<"     "<<"Sewa Per"<<"     "<<"Bayar"<<"      "<<gba<<endl;
                        cout<<"   "<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
                    for(i=1;i<=o;i++){
                        cout<<"   "<<gba<<" "<<setiosflags(ios::left)<<setw(6)<<i;
                        cout<<setiosflags(ios::left)<<setw(25)<<nama[i];
                        cout<<setiosflags(ios::left)<<setw(26)<<team[i];
                        cout<<setiosflags(ios::left)<<setw(15)<<hari_sewa[i];
                        cout<<setiosflags(ios::left)<<setw(14)<<sewa[i];
                        cout<<setiosflags(ios::left)<<setw(13)<<harjam[i];
                        cout<<setiosflags(ios::left)<<setw(11)<<bayar[i]<<gba<<endl;
                    }
                        cout<<"   "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                    getch(); goto menu_pembuka;
            }
            else if(liat_jadwal=="minggu"||liat_jadwal=="7"){
                hari_sewa[o]== "minggu";
                    cout<<"\t\t\t\t\t\t\t"<<"DAFTAR PENYEWA"<<endl;
                        cout<<"   "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"   "<<gba<<" No."<<"   "<<"Nama"<<"                     "<<"Nama TEAM"<<"                 "<<"Gor"<<"            "<<"Lama Sewa"<<"     "<<"Sewa Per"<<"     "<<"Bayar"<<"      "<<gba<<endl;
                        cout<<"   "<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
                    for(i=1;i<=o;i++){
                        cout<<"   "<<gba<<" "<<setiosflags(ios::left)<<setw(6)<<i;
                        cout<<setiosflags(ios::left)<<setw(25)<<nama[i];
                        cout<<setiosflags(ios::left)<<setw(26)<<team[i];
                        cout<<setiosflags(ios::left)<<setw(15)<<hari_sewa[i];
                        cout<<setiosflags(ios::left)<<setw(14)<<sewa[i];
                        cout<<setiosflags(ios::left)<<setw(13)<<harjam[i];
                        cout<<setiosflags(ios::left)<<setw(11)<<bayar[i]<<gba<<endl;
                    }
                        cout<<"   "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                    getch(); goto menu_pembuka;
            }
            else{
                goto coba;
            }
        if(o<1){
                system("cls");
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"\t\t\t\t"<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"\t\t\t\t"<<gba<<"                   BELUM ADA YANG SEWA                  "<<gba<<endl;
                        cout<<"\t\t\t\t"<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                        cout<<"\t\t\t\tInput huruf apa saja untuk kembali = ";
                        getch();
                        goto menu_pembuka;
            }
            else {
                system("cls");
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"\t\t\t\t\t\t\t"<<"DAFTAR PENYEWA"<<endl;
                        cout<<"   "<<tkb<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tbk<<endl;
                        cout<<"   "<<gba<<" No."<<"   "<<"Nama"<<"                     "<<"Nama TEAM"<<"                 "<<"Gor"<<"            "<<"Lama Sewa"<<"     "<<"Sewa Per"<<"     "<<"Bayar"<<"      "<<gba<<endl;
                        cout<<"   "<<tab<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tba<<endl;
                    for(i=1;i<=o;i++){
                        cout<<"   "<<gba<<" "<<setiosflags(ios::left)<<setw(6)<<i;
                        cout<<setiosflags(ios::left)<<setw(25)<<nama[i];
                        cout<<setiosflags(ios::left)<<setw(26)<<team[i];
                        cout<<setiosflags(ios::left)<<setw(15)<<hari_sewa[i];
                        cout<<setiosflags(ios::left)<<setw(14)<<sewa[i];
                        cout<<setiosflags(ios::left)<<setw(13)<<harjam[i];
                        cout<<setiosflags(ios::left)<<setw(11)<<bayar[i]<<gba<<endl;
                    }
                        cout<<"   "<<tak<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<gps<<tka<<endl;
                    getch(); goto menu_pembuka;
            }
        break;

    case 3: /*================================================ PILIHAN 3 ==========================================================*/
        system("cls");
        cout<<"Info Gor"<<endl;

            }

    }
